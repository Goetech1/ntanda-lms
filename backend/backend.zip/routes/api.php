<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\TenantController;
use App\Http\Controllers\CourseController;
use App\Http\Controllers\CourseModuleController;
use App\Http\Controllers\LessonController;
use App\Http\Controllers\EnrollmentController;
use App\Http\Controllers\AssessmentController;
use App\Http\Controllers\CourseCategoryController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\CertificateController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\AttendanceController;
use App\Http\Controllers\ExamController;
use App\Http\Controllers\InstitutionController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\AcademicSessionController;
use App\Http\Controllers\InstructorController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\SubscriptionController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\AnalyticsController;
use App\Http\Controllers\AiController;
use App\Http\Controllers\AuditLogController;
use App\Http\Controllers\VirtualClassroomController;
use App\Http\Controllers\CmsController;
use App\Http\Controllers\LibraryController;

/*
|--------------------------------------------------------------------------
| API Routes - Matching existing NestJS endpoints
|--------------------------------------------------------------------------
*/

// ─── Health Check ────────────────────────────────────────────────────────────
Route::get('/health', fn() => response()->json(['status' => 'ok', 'framework' => 'Laravel', 'timestamp' => now()]));

// ─── Public Routes (No Auth) ─────────────────────────────────────────────────
Route::prefix('auth')->group(function () {
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/refresh', [AuthController::class, 'refresh']);
    Route::post('/register-institution', [AuthController::class, 'registerInstitution']);
    Route::post('/google', [AuthController::class, 'googleLogin']);
    Route::post('/microsoft', [AuthController::class, 'microsoftLogin']);
});

// Public tenant resolver
Route::get('/tenant/resolve', [TenantController::class, 'resolve']);

// Payment webhooks (no auth)
Route::post('/v1/payments/webhook/stripe', [PaymentController::class, 'webhookStripe']);
Route::post('/v1/payments/webhook/paystack', [PaymentController::class, 'webhookPaystack']);
Route::post('/v1/payments/webhook/flutterwave', [PaymentController::class, 'webhookFlutterwave']);

// Certificate validation (public)
Route::get('/certificates/validate/{code}', [CertificateController::class, 'validate']);

// ─── Protected Routes (JWT Auth) ─────────────────────────────────────────────
Route::middleware('auth:api')->group(function () {

    // Auth
    Route::post('/auth/logout', [AuthController::class, 'logout']);
    Route::post('/auth/2fa/enable', [AuthController::class, 'enable2FA']);
    Route::get('/auth/devices', [AuthController::class, 'getDevices']);

    // Users
    Route::apiResource('users', UserController::class);

    // Tenants
    Route::get('/tenant', [TenantController::class, 'currentTenant']);
    Route::patch('/tenant', [TenantController::class, 'updateCurrentTenant']);
    Route::apiResource('tenants', TenantController::class);

    // Courses
    Route::apiResource('courses', CourseController::class);
    Route::post('/courses/{id}/clone', [CourseController::class, 'clone']);
    Route::post('/courses/{id}/versions', [CourseController::class, 'createVersion']);

    // Course Modules
    Route::get('/course-modules/by-course/{courseId}', [CourseModuleController::class, 'index']);
    Route::apiResource('course-modules', CourseModuleController::class)->except(['index']);

    // Lessons
    Route::get('/lessons/by-module/{moduleId}', [LessonController::class, 'index']);
    Route::apiResource('lessons', LessonController::class)->except(['index']);

    // Enrollments
    Route::post('/enrollments', [EnrollmentController::class, 'store']);
    Route::get('/enrollments/my-enrollments', [EnrollmentController::class, 'myEnrollments']);
    Route::get('/enrollments/by-course/{courseId}', [EnrollmentController::class, 'byCourse']);
    Route::patch('/enrollments/{id}/progress', [EnrollmentController::class, 'updateProgress']);

    // Assessments
    Route::apiResource('assessments', AssessmentController::class);

    // Course Categories
    Route::apiResource('course-categories', CourseCategoryController::class);

    // Payments
    Route::get('/v1/payments', [PaymentController::class, 'index']);
    Route::post('/v1/payments/stripe/checkout', [PaymentController::class, 'checkoutStripe']);
    Route::post('/v1/payments/paystack/checkout', [PaymentController::class, 'checkoutPaystack']);
    Route::post('/v1/payments/flutterwave/checkout', [PaymentController::class, 'checkoutFlutterwave']);

    // Certificates
    Route::get('/certificates', [CertificateController::class, 'index']);
    Route::post('/certificates', [CertificateController::class, 'store']);

    // Notifications
    Route::get('/notifications', [NotificationController::class, 'index']);
    Route::post('/notifications', [NotificationController::class, 'store']);
    Route::patch('/notifications/{id}/read', [NotificationController::class, 'markRead']);
    Route::patch('/notifications/read-all', [NotificationController::class, 'markAllRead']);
    Route::delete('/notifications/{id}', [NotificationController::class, 'destroy']);

    // Attendance
    Route::get('/attendance/by-course/{courseId}', [AttendanceController::class, 'index']);
    Route::post('/attendance', [AttendanceController::class, 'store']);
    Route::get('/attendance/by-student/{userId}', [AttendanceController::class, 'byStudent']);

    // Exams
    Route::get('/exams', [ExamController::class, 'index']);
    Route::post('/exams', [ExamController::class, 'store']);
    Route::get('/exams/{id}', [ExamController::class, 'show']);
    Route::post('/exams/{examId}/start', [ExamController::class, 'startAttempt']);
    Route::patch('/exam-attempts/{attemptId}/complete', [ExamController::class, 'completeAttempt']);

    // Institution
    Route::get('/institution', [InstitutionController::class, 'show']);
    Route::patch('/institution', [InstitutionController::class, 'update']);

    // Departments
    Route::apiResource('departments', DepartmentController::class);

    // Academic Sessions
    Route::apiResource('academic-sessions', AcademicSessionController::class);

    // Instructors
    Route::apiResource('instructors', InstructorController::class);

    // Students
    Route::get('/students', [StudentController::class, 'index']);
    Route::post('/students', [StudentController::class, 'store']);
    Route::get('/students/{id}', [StudentController::class, 'show']);
    Route::patch('/students/{id}', [StudentController::class, 'update']);

    // Subscriptions
    Route::get('/subscriptions', [SubscriptionController::class, 'index']);
    Route::post('/subscriptions', [SubscriptionController::class, 'store']);
    Route::get('/subscriptions/{id}', [SubscriptionController::class, 'show']);
    Route::patch('/subscriptions/{id}', [SubscriptionController::class, 'update']);

    // Roles & Permissions
    Route::apiResource('roles', RoleController::class);
    Route::get('/permissions', [PermissionController::class, 'index']);

    // Analytics
    Route::get('/analytics/dashboard', [AnalyticsController::class, 'dashboard']);
    Route::get('/analytics/course/{courseId}', [AnalyticsController::class, 'courseAnalytics']);
    Route::get('/analytics/student/{userId}', [AnalyticsController::class, 'studentAnalytics']);

    // AI
    Route::post('/ai/chat', [AiController::class, 'chat']);
    Route::get('/ai/history', [AiController::class, 'history']);

    // Audit Logs
    Route::get('/audit-logs', [AuditLogController::class, 'index']);

    // Virtual Classroom
    Route::post('/virtual-classroom', [VirtualClassroomController::class, 'create']);
    Route::post('/virtual-classroom/{roomId}/join', [VirtualClassroomController::class, 'join']);

    // CMS
    Route::get('/cms/pages', [CmsController::class, 'getPages']);
    Route::post('/cms/pages', [CmsController::class, 'savePage']);

    // Library
    Route::get('/library', [LibraryController::class, 'index']);
    Route::post('/library', [LibraryController::class, 'upload']);
});

Route::get('/ping', function() { return 'pong'; });
