<?php
namespace App\Http\Controllers;
use App\Models\AiInteraction;
use App\Services\AiTutorService;
use Illuminate\Http\Request;

class AiController extends Controller
{
    public function chat(Request $request, AiTutorService $aiTutor)
    {
        $request->validate([
            'prompt' => 'required|string|max:2000',
            'history' => 'nullable|array'
        ]);

        try {
            $prompt = $request->prompt;
            $history = $request->history ?? [];

            $response = $aiTutor->ask($prompt, $history);

            // Log interaction
            AiInteraction::create([
                'tenant_id' => $request->user()->tenant_id,
                'user_id' => $request->user()->id,
                'prompt' => $prompt,
                'response' => $response,
            ]);

            return response()->json([
                'success' => true,
                'response' => $response
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function history(Request $request) { 
        return response()->json(AiInteraction::where('tenant_id', $request->user()->tenant_id)->where('user_id', $request->user()->id)->orderBy('created_at', 'desc')->limit(50)->get()); 
    }
}
