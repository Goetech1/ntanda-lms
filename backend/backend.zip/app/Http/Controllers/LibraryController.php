<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;

class LibraryController extends Controller
{
    public function index(Request $request) { return response()->json(['resources' => []]); }
    public function upload(Request $request) { return response()->json(['success' => true, 'message' => 'Resource uploaded']); }
}
