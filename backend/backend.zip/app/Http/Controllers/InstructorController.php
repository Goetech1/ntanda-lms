<?php
namespace App\Http\Controllers;
use App\Models\InstructorProfile;
use Illuminate\Http\Request;

class InstructorController extends Controller
{
    public function index(Request $request) { return response()->json(InstructorProfile::where('tenant_id', $request->user()->tenant_id)->with('user:id,full_name,email')->get()); }
    public function store(Request $request)
    {
        $request->validate(['userId' => 'required|uuid']);
        return response()->json(InstructorProfile::create(['tenant_id' => $request->user()->tenant_id, 'user_id' => $request->userId, 'bio' => $request->bio, 'expertise' => $request->expertise, 'qualifications' => $request->qualifications, 'teaching_subjects' => $request->teachingSubjects]), 201);
    }
    public function show(Request $request, string $id) { return response()->json(InstructorProfile::where('id', $id)->where('tenant_id', $request->user()->tenant_id)->with('user:id,full_name,email')->firstOrFail()); }
    public function update(Request $request, string $id) { $p = InstructorProfile::where('id', $id)->where('tenant_id', $request->user()->tenant_id)->firstOrFail(); $p->update($request->only(['bio', 'expertise', 'qualifications', 'teaching_subjects'])); return response()->json($p); }
    public function destroy(Request $request, string $id) { InstructorProfile::where('id', $id)->where('tenant_id', $request->user()->tenant_id)->firstOrFail()->delete(); return response()->json(['success' => true]); }
}
