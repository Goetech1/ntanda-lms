<?php

namespace App\Http\Controllers;

use App\Models\Enrollment;
use Illuminate\Http\Request;

class EnrollmentController extends Controller
{
    public function store(Request $request)
    {
        $request->validate(['courseId' => 'required|uuid']);
        $tenantId = $request->user()->tenant_id;
        $userId = $request->user()->id;

        $existing = Enrollment::where('tenant_id', $tenantId)->where('user_id', $userId)->where('course_id', $request->courseId)->first();
        if ($existing) {
            return response()->json(['message' => 'User is already enrolled in this course'], 409);
        }

        $enrollment = Enrollment::create([
            'tenant_id' => $tenantId,
            'user_id' => $userId,
            'course_id' => $request->courseId,
            'progress_percentage' => 0,
        ]);

        return response()->json($enrollment, 201);
    }

    public function myEnrollments(Request $request)
    {
        $enrollments = Enrollment::where('user_id', $request->user()->id)
            ->where('tenant_id', $request->user()->tenant_id)
            ->with(['course.instructor:id,full_name'])
            ->get();
        return response()->json($enrollments);
    }

    public function byCourse(Request $request, string $courseId)
    {
        $enrollments = Enrollment::where('course_id', $courseId)
            ->where('tenant_id', $request->user()->tenant_id)
            ->with(['user:id,full_name,email'])
            ->get();
        return response()->json($enrollments);
    }

    public function updateProgress(Request $request, string $id)
    {
        $request->validate(['progress' => 'required|integer|min:0|max:100']);
        $enrollment = Enrollment::where('id', $id)->where('tenant_id', $request->user()->tenant_id)->firstOrFail();
        $enrollment->update([
            'progress_percentage' => $request->progress,
            'completed_at' => $request->progress === 100 ? now() : null,
        ]);
        return response()->json($enrollment);
    }
}
