<?php

namespace App\Http\Controllers;

use App\Models\Assessment;
use Illuminate\Http\Request;

class AssessmentController extends Controller
{
    public function index(Request $request)
    {
        return response()->json(Assessment::where('tenant_id', $request->user()->tenant_id)->with('course:id,title')->get());
    }

    public function store(Request $request)
    {
        $request->validate(['courseId' => 'required|uuid', 'title' => 'required', 'type' => 'required|in:QUIZ,ASSIGNMENT,EXAM', 'totalPoints' => 'required|integer']);
        return response()->json(Assessment::create([
            'tenant_id' => $request->user()->tenant_id,
            'course_id' => $request->courseId,
            'title' => $request->title,
            'type' => $request->type,
            'time_limit_minutes' => $request->timeLimitMinutes,
            'total_points' => $request->totalPoints,
        ]), 201);
    }

    public function show(Request $request, string $id)
    {
        return response()->json(Assessment::where('id', $id)->where('tenant_id', $request->user()->tenant_id)->with('questions')->firstOrFail());
    }

    public function update(Request $request, string $id)
    {
        $a = Assessment::where('id', $id)->where('tenant_id', $request->user()->tenant_id)->firstOrFail();
        $a->update($request->only(['title', 'type', 'time_limit_minutes', 'total_points']));
        return response()->json($a);
    }

    public function destroy(Request $request, string $id)
    {
        Assessment::where('id', $id)->where('tenant_id', $request->user()->tenant_id)->firstOrFail()->delete();
        return response()->json(['success' => true]);
    }
}
