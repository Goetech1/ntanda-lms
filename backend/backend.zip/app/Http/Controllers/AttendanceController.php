<?php
namespace App\Http\Controllers;
use App\Models\Attendance;
use Illuminate\Http\Request;

class AttendanceController extends Controller
{
    public function index(Request $request, string $courseId)
    {
        return response()->json(Attendance::where('course_id', $courseId)->where('tenant_id', $request->user()->tenant_id)->with('user:id,full_name')->get());
    }

    public function store(Request $request)
    {
        $request->validate(['courseId' => 'required|uuid', 'userId' => 'required|uuid', 'date' => 'required|date', 'status' => 'required|in:PRESENT,ABSENT,LATE,EXCUSED']);
        return response()->json(Attendance::create([
            'tenant_id' => $request->user()->tenant_id,
            'course_id' => $request->courseId,
            'user_id' => $request->userId,
            'date' => $request->date,
            'status' => $request->status,
            'remarks' => $request->remarks,
        ]), 201);
    }

    public function byStudent(Request $request, string $userId)
    {
        return response()->json(Attendance::where('user_id', $userId)->where('tenant_id', $request->user()->tenant_id)->with('course:id,title')->get());
    }
}
