<?php
namespace App\Http\Controllers;
use App\Models\Role;
use Illuminate\Http\Request;

class RoleController extends Controller
{
    public function index(Request $request) { return response()->json(Role::where(function($q) use ($request) { $q->where('tenant_id', $request->user()->tenant_id)->orWhereNull('tenant_id'); })->with('permissions')->get()); }
    public function store(Request $request)
    {
        $request->validate(['name' => 'required']);
        $role = Role::create(['tenant_id' => $request->user()->tenant_id, 'name' => $request->name, 'description' => $request->description]);
        if ($request->permissionIds) { $role->permissions()->sync($request->permissionIds); }
        return response()->json($role->load('permissions'), 201);
    }
    public function show(string $id) { return response()->json(Role::with('permissions')->findOrFail($id)); }
    public function update(Request $request, string $id) { $r = Role::findOrFail($id); $r->update($request->only(['name', 'description'])); if ($request->permissionIds) { $r->permissions()->sync($request->permissionIds); } return response()->json($r->load('permissions')); }
    public function destroy(string $id) { Role::findOrFail($id)->delete(); return response()->json(['success' => true]); }
}
