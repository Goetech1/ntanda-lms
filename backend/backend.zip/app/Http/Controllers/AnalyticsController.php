<?php
namespace App\Http\Controllers;
use App\Models\Enrollment;
use App\Models\Course;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AnalyticsController extends Controller
{
    public function dashboard(Request $request)
    {
        $tenantId = $request->user()->tenant_id;
        return response()->json([
            'totalStudents' => DB::table('users')->where('tenant_id', $tenantId)->join('roles', 'users.role_id', '=', 'roles.id')->where('roles.name', 'STUDENT')->count(),
            'totalCourses' => DB::table('courses')->where('tenant_id', $tenantId)->whereNull('deleted_at')->count(),
            'totalEnrollments' => DB::table('enrollments')->where('tenant_id', $tenantId)->count(),
            'totalRevenue' => DB::table('payments')->where('tenant_id', $tenantId)->where('status', 'COMPLETED')->sum('amount'),
        ]);
    }

    public function courseAnalytics(Request $request, string $courseId)
    {
        $tenantId = $request->user()->tenant_id;
        return response()->json([
            'enrollmentCount' => DB::table('enrollments')->where('tenant_id', $tenantId)->where('course_id', $courseId)->count(),
            'avgProgress' => DB::table('enrollments')->where('tenant_id', $tenantId)->where('course_id', $courseId)->avg('progress_percentage') ?? 0,
            'completionCount' => DB::table('enrollments')->where('tenant_id', $tenantId)->where('course_id', $courseId)->whereNotNull('completed_at')->count(),
        ]);
    }

    public function studentAnalytics(Request $request, string $userId)
    {
        $tenantId = $request->user()->tenant_id;
        return response()->json([
            'enrolledCourses' => DB::table('enrollments')->where('tenant_id', $tenantId)->where('user_id', $userId)->count(),
            'completedCourses' => DB::table('enrollments')->where('tenant_id', $tenantId)->where('user_id', $userId)->whereNotNull('completed_at')->count(),
            'avgProgress' => DB::table('enrollments')->where('tenant_id', $tenantId)->where('user_id', $userId)->avg('progress_percentage') ?? 0,
        ]);
    }
}
