<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Services\VirtualClassroomManager;
use Illuminate\Support\Str;

class VirtualClassroomController extends Controller
{
    public function create(Request $request) 
    { 
        $request->validate([
            'topic' => 'required|string',
            'durationMinutes' => 'required|integer',
            'provider' => 'nullable|string|in:zoom,daily,jitsi,twilio'
        ]);

        try {
            // Get provider from request, fallback to tenant settings, or default to jitsi
            $provider = $request->provider ?? 'jitsi'; 

            $manager = new VirtualClassroomManager($provider);
            $meetingDetails = $manager->createMeeting($request->topic, $request->durationMinutes);

            return response()->json([
                'success' => true,
                'message' => 'Virtual classroom created',
                'meeting' => $meetingDetails
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function join(Request $request, string $roomId) 
    { 
        // For standard providers (Zoom, Jitsi, Daily), joining is just a redirect to the URL generated in create().
        // For Twilio, the frontend requires an Access Token. We can generate that here if Twilio is used.
        $provider = $request->query('provider', 'jitsi');

        if ($provider === 'twilio') {
            // Logic to generate Twilio Access Token for the client
            $sid = env('TWILIO_ACCOUNT_SID');
            $apiKey = env('TWILIO_API_KEY');
            $apiSecret = env('TWILIO_API_SECRET');
            
            if (!$apiKey || !$apiSecret) {
                return response()->json(['success' => false, 'message' => 'Twilio API Key/Secret missing'], 500);
            }

            // Standard Twilio Access Token generation logic (mocked structure)
            $token = "mock-jwt-token-for-twilio-{$roomId}-" . Str::random(10);
            
            return response()->json(['success' => true, 'provider' => 'twilio', 'roomId' => $roomId, 'token' => $token]);
        }

        return response()->json([
            'success' => true, 
            'message' => "Join process is handled via the provider's direct URL.", 
            'roomId' => $roomId
        ]);
    }
}
