<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class Question extends Model
{
    use HasUuids;
    public $timestamps = false;
    protected $fillable = ['tenant_id', 'assessment_id', 'content', 'options', 'correct_answer', 'points', 'order_index'];
    protected $casts = ['options' => 'array', 'correct_answer' => 'array'];

    public function tenant() { return $this->belongsTo(Tenant::class); }
    public function assessment() { return $this->belongsTo(Assessment::class); }
}
