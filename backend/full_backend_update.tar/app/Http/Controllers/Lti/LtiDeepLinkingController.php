<?php

namespace App\Http\Controllers\Lti;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LtiDeepLinkingController extends Controller
{
    /**
     * Called by our React frontend to generate the signed LTI Deep Linking Response.
     */
    public function generateResponse(Request $request)
    {
        $request->validate([
            'return_url' => 'required|url',
            'course_id' => 'required|uuid',
            'course_title' => 'required|string',
        ]);

        $tenantId = $request->user()->tenant_id;
        
        // Find a matching platform for this tenant
        $platform = DB::table('lti_platforms')
            ->where('tenant_id', $tenantId)
            ->first();

        if (!$platform) {
            return response()->json(['error' => 'No LTI Platform configured for this tenant'], 400);
        }

        // Construct the ContentItem payload
        $contentItem = [
            'type' => 'ltiResourceLink',
            'title' => $request->course_title,
            'url' => env('APP_URL') . '/api/lti/launch',
            'custom' => [
                'course_id' => $request->course_id
            ]
        ];

        // Construct the JWT Payload
        $jwtPayload = [
            'iss' => $platform->client_id, // We act as the tool (issuer) here usually it's the client ID
            'aud' => $platform->issuer,    // The LMS
            'iat' => time(),
            'exp' => time() + 300,         // 5 minutes
            'https://purl.imsglobal.org/spec/lti/claim/message_type' => 'LtiDeepLinkingResponse',
            'https://purl.imsglobal.org/spec/lti/claim/version' => '1.3.0',
            'https://purl.imsglobal.org/spec/lti/claim/deployment_id' => $platform->deployment_id,
            'https://purl.imsglobal.org/spec/lti-dl/claim/content_items' => [
                $contentItem
            ]
        ];

        // In a real production environment, this payload MUST be signed with RS256 using the tool's private key.
        // For MVP architecture demonstration, we will return the base64 encoded JWT structure.
        
        $header = base64_encode(json_encode(['alg' => 'none', 'typ' => 'JWT'])); // None alg for MVP mock
        $payload = base64_encode(json_encode($jwtPayload));
        $signature = ''; // Empty signature for MVP mock

        $jwt = $header . '.' . $payload . '.' . $signature;

        return response()->json([
            'jwt' => $jwt,
            'return_url' => $request->return_url
        ]);
    }
}
