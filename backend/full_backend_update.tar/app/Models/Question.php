<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class Question extends Model
{
    use HasUuids;

    protected $fillable = ['tenant_id', 'category_id', 'type', 'text', 'options_json', 'answer_json'];
    
    protected $casts = [
        'options_json' => 'array',
        'answer_json' => 'array',
    ];

    public function tenant() { return $this->belongsTo(Tenant::class); }
    public function category() { return $this->belongsTo(QuestionCategory::class, 'category_id'); }
}
